import React from 'react';
import { Linkedin, Mail, Phone, ExternalLink } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 text-white">
      {/* Hero Section */}
      <header className="container mx-auto px-4 py-16 flex flex-col md:flex-row items-center justify-between">
        <div className="md:w-1/2 text-center md:text-left">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">
            Hi, I'm <span className="text-blue-400">Karthik Reddy</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-8">
            Full Stack Developer | Student at KSRM College of Engineering
          </p>
          <div className="flex gap-4 justify-center md:justify-start">
            <a href="https://www.linkedin.com/in/karthikchennuru" target="_blank" rel="noopener noreferrer" className="hover:text-blue-400 transition-colors">
              <Linkedin size={24} />
            </a>
            <a href="mailto:ckarthikreddy788@gmail.com" className="hover:text-blue-400 transition-colors">
              <Mail size={24} />
            </a>
            <a href="tel:+919390403102" className="hover:text-blue-400 transition-colors">
              <Phone size={24} />
            </a>
          </div>
        </div>
        <div className="md:w-1/2 mt-8 md:mt-0">
          <img 
            src="https://res.cloudinary.com/dwaovlupr/image/upload/v1720940660/karthik_photo_gf3afh.jpg" 
            alt="Karthik Reddy"
            className="rounded-full w-64 h-64 object-cover mx-auto border-4 border-blue-400"
          />
        </div>
      </header>

      {/* About Section */}
      <section className="bg-gray-800 py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8 text-center">About Me</h2>
          <div className="max-w-3xl mx-auto text-gray-300">
            <p className="mb-4">
              I am a passionate Full Stack Developer currently pursuing my B.Tech at KSRM College of Engineering. 
              With a strong foundation in both front-end and back-end development, I specialize in creating 
              responsive and user-friendly web applications using modern technologies.
            </p>
            <p className="mb-4">
              My technical expertise includes working with React.js, Node.js, and various databases. I am 
              constantly learning and staying updated with the latest technologies in the field of web development.
            </p>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8 text-center">Featured Projects</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {/* Project 1 */}
            <div className="bg-gray-700 rounded-lg overflow-hidden group">
              <div className="relative">
                <img 
                  src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=400&fit=crop" 
                  alt="E-Commerce Website"
                  className="w-full h-48 object-cover group-hover:opacity-75 transition-opacity"
                />
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <a href="https://project1.example.com" target="_blank" rel="noopener noreferrer" className="bg-blue-500 p-2 rounded-full">
                    <ExternalLink size={24} />
                  </a>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">E-Commerce Website</h3>
                <p className="text-gray-300 mb-4">
                  A full-featured e-commerce platform built with React, Node.js, and MongoDB. 
                  Includes user authentication, product management, and payment integration.
                </p>
                <div className="flex flex-wrap gap-2">
                  <span className="bg-blue-500 px-3 py-1 rounded-full text-sm">React</span>
                  <span className="bg-blue-500 px-3 py-1 rounded-full text-sm">Node.js</span>
                  <span className="bg-blue-500 px-3 py-1 rounded-full text-sm">MongoDB</span>
                </div>
              </div>
            </div>

            {/* Project 2 */}
            <div className="bg-gray-700 rounded-lg overflow-hidden group">
              <div className="relative">
                <img 
                  src="https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&h=400&fit=crop" 
                  alt="Task Management App"
                  className="w-full h-48 object-cover group-hover:opacity-75 transition-opacity"
                />
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <a href="https://project2.example.com" target="_blank" rel="noopener noreferrer" className="bg-blue-500 p-2 rounded-full">
                    <ExternalLink size={24} />
                  </a>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Task Management App</h3>
                <p className="text-gray-300 mb-4">
                  A collaborative task management application with real-time updates, 
                  team collaboration features, and progress tracking.
                </p>
                <div className="flex flex-wrap gap-2">
                  <span className="bg-blue-500 px-3 py-1 rounded-full text-sm">Vue.js</span>
                  <span className="bg-blue-500 px-3 py-1 rounded-full text-sm">Firebase</span>
                  <span className="bg-blue-500 px-3 py-1 rounded-full text-sm">Tailwind CSS</span>
                </div>
              </div>
            </div>

            {/* Project 3 */}
            <div className="bg-gray-700 rounded-lg overflow-hidden group">
              <div className="relative">
                <img 
                  src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=400&fit=crop" 
                  alt="Portfolio Website"
                  className="w-full h-48 object-cover group-hover:opacity-75 transition-opacity"
                />
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <a href="https://project3.example.com" target="_blank" rel="noopener noreferrer" className="bg-blue-500 p-2 rounded-full">
                    <ExternalLink size={24} />
                  </a>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Portfolio Website</h3>
                <p className="text-gray-300 mb-4">
                  A modern portfolio website built with React and Tailwind CSS, 
                  featuring smooth animations and responsive design.
                </p>
                <div className="flex flex-wrap gap-2">
                  <span className="bg-blue-500 px-3 py-1 rounded-full text-sm">React</span>
                  <span className="bg-blue-500 px-3 py-1 rounded-full text-sm">Tailwind CSS</span>
                  <span className="bg-blue-500 px-3 py-1 rounded-full text-sm">Framer Motion</span>
                </div>
              </div>
            </div>

            {/* Project 4 */}
            <div className="bg-gray-700 rounded-lg overflow-hidden group">
              <div className="relative">
                <img 
                  src="https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?w=800&h=400&fit=crop" 
                  alt="Weather App"
                  className="w-full h-48 object-cover group-hover:opacity-75 transition-opacity"
                />
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <a href="https://project4.example.com" target="_blank" rel="noopener noreferrer" className="bg-blue-500 p-2 rounded-full">
                    <ExternalLink size={24} />
                  </a>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Weather Dashboard</h3>
                <p className="text-gray-300 mb-4">
                  A weather dashboard application with location-based forecasts, 
                  interactive maps, and detailed weather information.
                </p>
                <div className="flex flex-wrap gap-2">
                  <span className="bg-blue-500 px-3 py-1 rounded-full text-sm">React</span>
                  <span className="bg-blue-500 px-3 py-1 rounded-full text-sm">OpenWeatherMap API</span>
                  <span className="bg-blue-500 px-3 py-1 rounded-full text-sm">Chart.js</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Education Section */}
      <section className="bg-gray-800 py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8 text-center">Education</h2>
          <div className="max-w-3xl mx-auto">
            <div className="bg-gray-700 rounded-lg p-6 mb-6">
              <h3 className="text-xl font-bold mb-2">Bachelor of Technology in Electronics Communication and Enginnering</h3>
              <p className="text-gray-300">KSRM College of Engineering</p>
              <p className="text-gray-400">2020 - 2024</p>
              <p className="text-gray-300 mt-2">CGPA: 8.5/10</p>
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8 text-center">Skills</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto">
            {[
              'JavaScript', 'React', 'Node.js', 'HTML/CSS',
              'Python', 'Git', 'TypeScript', 'SQL',
              'MongoDB', 'Express.js', 'Tailwind CSS', 'RESTful APIs'
            ].map((skill) => (
              <div key={skill} className="bg-gray-700 rounded-lg p-4 text-center hover:bg-gray-600 transition-colors">
                {skill}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="bg-gray-800 py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-8">Get In Touch</h2>
          <p className="text-gray-300 mb-8">
            I'm currently looking for new opportunities and would love to hear from you.
          </p>
          <a 
            href="mailto:ckarthikreddy788@gmail.com"
            className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 rounded-full font-semibold transition-colors"
          >
            Contact Me
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 py-8">
        <div className="container mx-auto px-4 text-center text-gray-400">
          <p>© 2024 Karthik Reddy. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;